# kt-woocommerce

## Yükleme

1. Wordpress admin paneli açılıp Plugins->Installed Plugins seçeneğine gidilir  

2. KT Payment Module bulunur ve aktif edilir

3. Modül aktivasyonunun akabinde,  "Woocommerce->settings->Payment" seçeneğine gidilir ve KT Payment Module kısmında "Manage" tıklanır

4. "KTPay Modülü aktifleştirme" seçeneğinin seçili olduğu görülür

5. Kuveyttürk Kullanıcı Bilgileri girişi yapılır

6. Bilgiler girildikten sonra ayarlar kaydedilir ve KT Payment Module aktif olmuş olur.