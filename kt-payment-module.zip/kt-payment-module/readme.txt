=== kt-payment-module ===
Contributors: KuveytTürk
Tags: payment, KT Payment Module
Stable tag: 1.0.0
Requires at least: 4.0
WC requires at least: 5.1.0
WC tested up to: 7.5.1
Tested up to: 6.2
Requires PHP: 7.0

Architecht tarafından geliştirilen KT Woocommerce ödeme modülü. 

== Description ==
Kuveyttürk ödeme altyapısıyla Woocommerce kullanan müşterilerin 3D, Non3D sanal pos işlemlerinin gerçekleştiribileceği eklentidir.

== Yükleme ==

1. Wordpress admin paneli açılıp Plugins->Installed Plugins seçeneğine gidilir  

2. KT Payment Module bulunur ve aktif edilir

3. Modül aktivasyonunun akabinde,  "Woocommerce->settings->Payment" seçeneğine gidilir ve KT Payment Module kısmında "Manage" tıklanır

4. "KTPay Modülü aktifleştirme" seçeneğinin seçili olduğu görülür

5. Kuveyttürk Kullanıcı Bilgileri girişi yapılır

6. Bilgiler girildikten sonra ayarlar kaydedilir ve KT Payment Module aktif olmuş olur.

